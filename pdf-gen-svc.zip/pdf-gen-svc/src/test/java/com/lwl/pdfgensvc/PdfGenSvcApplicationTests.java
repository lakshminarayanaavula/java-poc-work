package com.lwl.pdfgensvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfGenSvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
